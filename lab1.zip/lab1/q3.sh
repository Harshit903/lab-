#!/bin/bash

#Write a Shell program to download a webpage, given url. And analyse download performance by running at different time of the day.


URL=https://www.reddit.com/

wget $URL

exit
